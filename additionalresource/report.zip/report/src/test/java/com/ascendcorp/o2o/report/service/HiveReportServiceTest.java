package com.ascendcorp.o2o.report.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.ascendcorp.o2o.report.ReportApp;
import com.ascendcorp.o2o.report.domain.MakroSettlement;
import com.ascendcorp.o2o.report.repository.HiveRepository;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = ReportApp.class)
public class HiveReportServiceTest {

    @Autowired
    private HiveReportService hiveReportService;
    
    @Mock
    private HiveRepository hiveRepository;

    private List<MakroSettlement> mockMakroSettlement() {
        List<MakroSettlement> mock = new ArrayList<>();
        MakroSettlement record = new MakroSettlement();
        record.setTransactionId("1");
        mock.add(record);
        return mock;
    }

    @Test
    public void testQueryMakroSettlementRecords() {
//        List<MakroSettlement> result = hiveReportService.getMakroSettlementRecords();
        when(hiveRepository.getMakroSettlementRecords(Mockito.anyInt())).thenReturn(mockMakroSettlement());
        List<MakroSettlement> result = hiveReportService.getMakroSettlementRecords(1);
        assertNotNull(result);
    }

}
