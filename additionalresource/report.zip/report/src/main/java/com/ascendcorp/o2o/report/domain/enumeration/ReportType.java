package com.ascendcorp.o2o.report.domain.enumeration;

/**
 * The ReportType enumeration.
 */
public enum ReportType {
    SETTLEMENT, MONTHLY
}
