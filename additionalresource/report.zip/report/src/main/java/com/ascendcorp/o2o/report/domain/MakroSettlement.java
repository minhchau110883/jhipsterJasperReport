package com.ascendcorp.o2o.report.domain;

import java.math.BigDecimal;

public class MakroSettlement {

    private String partnerTransactionId;

    private String transactionId;

    private String contractId;

    private String outletId;

    private String trueyouMid;

    private String outletName;

    private BigDecimal amount;

    private BigDecimal fee;

    private BigDecimal vat;

    private BigDecimal feeIncluded;

    private BigDecimal settlement;

    private String currency;

    private BigDecimal wht;

    private String paymentTime;

    private String paymentDate;

    private String settlementTime;

    private String type;

    private String sof;

    private String merchantId;

    private String paymentChannel;

    public String getPartnerTransactionId() {
        return partnerTransactionId;
    }

    public void setPartnerTransactionId(String partnerTransactionId) {
        this.partnerTransactionId = partnerTransactionId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getContractId() {
        return contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    public String getOutletId() {
        return outletId;
    }

    public void setOutletId(String outletId) {
        this.outletId = outletId;
    }

    public String getTrueyouMid() {
        return trueyouMid;
    }

    public void setTrueyouMid(String trueyouMid) {
        this.trueyouMid = trueyouMid;
    }

    public String getOutletName() {
        return outletName;
    }

    public void setOutletName(String outletName) {
        this.outletName = outletName;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getFee() {
        return fee;
    }

    public void setFee(BigDecimal fee) {
        this.fee = fee;
    }

    public BigDecimal getVat() {
        return vat;
    }

    public void setVat(BigDecimal vat) {
        this.vat = vat;
    }

    public BigDecimal getFeeIncluded() {
        return feeIncluded;
    }

    public void setFeeIncluded(BigDecimal feeIncluded) {
        this.feeIncluded = feeIncluded;
    }

    public BigDecimal getSettlement() {
        return settlement;
    }

    public void setSettlement(BigDecimal settlement) {
        this.settlement = settlement;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public BigDecimal getWht() {
        return wht;
    }

    public void setWht(BigDecimal wht) {
        this.wht = wht;
    }

    public String getPaymentTime() {
        return paymentTime;
    }

    public void setPaymentTime(String paymentTime) {
        this.paymentTime = paymentTime;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }

    public String getSettlementTime() {
        return settlementTime;
    }

    public void setSettlementTime(String settlementTime) {
        this.settlementTime = settlementTime;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSof() {
        return sof;
    }

    public void setSof(String sof) {
        this.sof = sof;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public String getPaymentChannel() {
        return paymentChannel;
    }

    public void setPaymentChannel(String paymentChannel) {
        this.paymentChannel = paymentChannel;
    }

}
