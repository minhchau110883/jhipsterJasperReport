/**
 * Spring Security configuration.
 */
package com.ascendcorp.o2o.report.security;
