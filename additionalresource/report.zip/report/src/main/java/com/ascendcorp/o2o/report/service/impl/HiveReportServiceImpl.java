package com.ascendcorp.o2o.report.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ascendcorp.o2o.report.domain.MakroSettlement;
import com.ascendcorp.o2o.report.repository.HiveRepository;
import com.ascendcorp.o2o.report.service.HiveReportService;

@Service
public class HiveReportServiceImpl implements HiveReportService {

    private final HiveRepository hiveRepository;

    @Value("${hive.query.limit}")
    private Integer defaultQueryLimit;

    public HiveReportServiceImpl(HiveRepository hiveRepository) {
        this.hiveRepository = hiveRepository;
    }

    @Override
    public List<MakroSettlement> getMakroSettlementRecords(int queryLimit) {
        queryLimit = queryLimit <= 0 ? defaultQueryLimit : queryLimit;
        return hiveRepository.getMakroSettlementRecords(queryLimit);
    }

}
