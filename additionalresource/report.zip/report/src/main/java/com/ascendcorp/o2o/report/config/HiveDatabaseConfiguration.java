package com.ascendcorp.o2o.report.config;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
public class HiveDatabaseConfiguration {

    @Value("${hive.datasource.type}")
    private String type;

    @Value("${hive.datasource.url}")
    private String url;

    @Value("${hive.datasource.username}")
    private String username;

    @Value("${hive.datasource.password}")
    private String password;

    @Bean("hiveDataSource")
    public DataSource hiveDataSource() {
        BasicDataSource dataSource = new BasicDataSource();
        dataSource.setDriverClassName(type);
        dataSource.setUrl(url);
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        return dataSource;
    }

    @Bean("hiveJdbcTemplate")
    public JdbcTemplate hiveJdbcTemplate(@Qualifier("hiveDataSource") DataSource hiveDataSource) {
        return new JdbcTemplate(hiveDataSource);
    }

}