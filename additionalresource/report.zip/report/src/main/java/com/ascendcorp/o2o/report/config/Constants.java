package com.ascendcorp.o2o.report.config;

import java.time.ZoneId;

/**
 * Application constants.
 */
public final class Constants {

    // Regex for acceptable logins
    public static final String LOGIN_REGEX = "^[_.@A-Za-z0-9-]*$";

    public static final String SYSTEM_ACCOUNT = "system";
    public static final String ANONYMOUS_USER = "anonymoususer";
    public static final String DEFAULT_LANGUAGE = "en";
    public static final String UTC_TIME_ZONE = "Etc/UTC";
    public static final ZoneId UTC_TIME_ZONE_ID = ZoneId.of(UTC_TIME_ZONE);
    public static final String REPORT_ID_JOB_DATA_KEY = "reportId";
    
    private Constants() {
    }
}
