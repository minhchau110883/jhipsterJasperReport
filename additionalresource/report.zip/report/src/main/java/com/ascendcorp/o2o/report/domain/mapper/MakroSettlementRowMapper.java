package com.ascendcorp.o2o.report.domain.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ascendcorp.o2o.report.domain.MakroSettlement;

public class MakroSettlementRowMapper implements RowMapper<MakroSettlement> {

    @Override
    public MakroSettlement mapRow(ResultSet rs, int rowNum) throws SQLException {
        MakroSettlement row = new MakroSettlement();
        row.setTrueyouMid(rs.getString("trueyou_mid"));
        row.setPartnerTransactionId(rs.getString("partner_transaction_id"));
        row.setTransactionId(rs.getString("transaction_id"));
        row.setContractId(rs.getString("contract_id"));
        row.setOutletId(rs.getString("outlet_id"));
        row.setOutletName(rs.getString("outlet_name"));
        row.setAmount(rs.getBigDecimal("amount"));
        row.setFee(rs.getBigDecimal("fee"));
        row.setVat(rs.getBigDecimal("vat"));
        row.setFeeIncluded(rs.getBigDecimal("fee_included"));
        row.setSettlement(rs.getBigDecimal("settlement"));
        row.setCurrency(rs.getString("currency"));
        row.setWht(rs.getBigDecimal("wht"));
        row.setPaymentTime(rs.getString("payment_time"));
        row.setPaymentDate(rs.getString("payment_date"));
        row.setSettlementTime(rs.getString("settlement_time"));
        row.setType(rs.getString("type"));
        row.setSof(rs.getString("sof"));
        row.setMerchantId(rs.getString("merchant_id"));
        row.setPaymentChannel(rs.getString("payment_channel"));
        return row;
    }

}
