package com.ascendcorp.o2o.report.service;

import com.ascendcorp.o2o.report.domain.Report;

public interface ReportService {
    Report generateMockReport(Report report);
    byte[] downloadReport(Long id) throws Exception;
}
