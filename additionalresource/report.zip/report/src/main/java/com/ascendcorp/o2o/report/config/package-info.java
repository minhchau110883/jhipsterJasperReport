/**
 * Spring Framework configuration files.
 */
package com.ascendcorp.o2o.report.config;
