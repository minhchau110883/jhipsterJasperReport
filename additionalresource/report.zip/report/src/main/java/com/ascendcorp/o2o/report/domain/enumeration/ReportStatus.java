package com.ascendcorp.o2o.report.domain.enumeration;

/**
 * The ReportStatus enumeration.
 */
public enum ReportStatus {
    CREATED, SENT, DOWNLOADED
}
