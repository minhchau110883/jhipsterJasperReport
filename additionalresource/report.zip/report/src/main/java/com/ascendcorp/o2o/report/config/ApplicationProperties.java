package com.ascendcorp.o2o.report.config;

import com.ascendcorp.o2o.report.domain.enumeration.ReportType;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Properties specific to Report.
 * <p>
 * Properties are configured in the application.yml file.
 * See {@link io.github.jhipster.config.JHipsterProperties} for a good example.
 */
@ConfigurationProperties(prefix = "application", ignoreUnknownFields = false)
public class ApplicationProperties {

    private AWSProperties aws;
    private ReportProperties settlementReport;
    private ReportProperties monthlyReport;

    public AWSProperties getAws() {
        return aws;
    }

    public void setAws(AWSProperties aws) {
        this.aws = aws;
    }

    public ReportProperties getSettlementReport() {
        return settlementReport;
    }

    public void setSettlementReport(ReportProperties settlementReport) {
        this.settlementReport = settlementReport;
    }

    public ReportProperties getMonthlyReport() {
        return monthlyReport;
    }

    public void setMonthlyReport(ReportProperties monthlyReport) {
        this.monthlyReport = monthlyReport;
    }

    public ReportProperties getReportPropertiesByType(ReportType type) {
        switch (type) {
            case SETTLEMENT: return settlementReport;
            case MONTHLY: return monthlyReport;
            default: return null;
        }
    }
}
