/**
 * Service layer beans.
 */
package com.ascendcorp.o2o.report.service;
