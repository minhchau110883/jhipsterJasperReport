/**
 * Spring Data JPA repositories.
 */
package com.ascendcorp.o2o.report.repository;
