package com.ascendcorp.o2o.report.service.impl;

import com.ascendcorp.o2o.report.config.ApplicationProperties;
import com.ascendcorp.o2o.report.config.ReportProperties;
import com.ascendcorp.o2o.report.domain.Report;
import com.ascendcorp.o2o.report.job.SendReportEmailJob;
import com.ascendcorp.o2o.report.service.ReportSchedulingService;
import org.quartz.CronExpression;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.TimeZone;
import java.util.UUID;

import static com.ascendcorp.o2o.report.config.Constants.REPORT_ID_JOB_DATA_KEY;
import static com.ascendcorp.o2o.report.config.Constants.UTC_TIME_ZONE_ID;

@Service
public class ReportSchedulingServiceImpl implements ReportSchedulingService {

    private final Logger log = LoggerFactory.getLogger(ReportSchedulingServiceImpl.class);

    private final Scheduler scheduler;
    private final ApplicationProperties applicationProperties;

    @Autowired
    public ReportSchedulingServiceImpl(Scheduler scheduler, ApplicationProperties applicationProperties) {
        this.scheduler = scheduler;
        this.applicationProperties = applicationProperties;
    }

    /**
     * Schedule a sending email job for report
     * @param report Report to send
     */
    @Override
    public void scheduleSendReportEmailJob(Report report) {
        try {
            JobDetail jobDetail = buildJobDetail(report);
            Trigger trigger = buildJobTrigger(report, jobDetail);
            scheduler.scheduleJob(jobDetail, trigger);
        } catch (Exception e) {
            log.error("Error while scheduling send email job for report ID {}", report.getId(), e);
        }
    }

    private JobDetail buildJobDetail(Report report) {
        JobDataMap jobDataMap = new JobDataMap();
        jobDataMap.put(REPORT_ID_JOB_DATA_KEY, report.getId());

        return JobBuilder.newJob(SendReportEmailJob.class)
            .withIdentity(UUID.randomUUID().toString(), "email-jobs")
            .withDescription("Send Email Job")
            .usingJobData(jobDataMap)
            .storeDurably()
            .requestRecovery()
            .build();
    }


    private Trigger buildJobTrigger(Report report, JobDetail jobDetail) throws ParseException {
        ZonedDateTime startOfToday = ZonedDateTime.now(UTC_TIME_ZONE_ID).truncatedTo(ChronoUnit.DAYS);
        ReportProperties reportProperties = applicationProperties.getReportPropertiesByType(report.getType());

        CronExpression cron = new CronExpression(reportProperties.getEmailScheduling().getCronExpression());
        cron.setTimeZone(TimeZone.getTimeZone(reportProperties.getEmailScheduling().getZone()));

        // Calculate next time to run a job from cron expression by starting from at start of today.
        // It means if our cron is at 8.30 of every day, but current time is 9.00.
        // The job will be scheduled at 8.30 of today. It will be treated as a mis-fire job and will trigger immediately.
        // A reason to do this is to make sure that all reports that cannot be generated before the schedule time
        // will still be sent to user within that day.
        Date startAt = cron.getNextValidTimeAfter(Date.from(startOfToday.toInstant()));
        log.info("Scheduling send email job start at {}", startAt);

        return TriggerBuilder.newTrigger()
            .forJob(jobDetail)
            .withIdentity(jobDetail.getKey().getName(), "email-triggers")
            .withDescription("Send Email Trigger")
            .startAt(Date.from(startAt.toInstant()))
            .withSchedule(SimpleScheduleBuilder.simpleSchedule().withMisfireHandlingInstructionFireNow())
            .build();
    }
}
