/**
 * Spring MVC REST controllers.
 */
package com.ascendcorp.o2o.report.web.rest;
