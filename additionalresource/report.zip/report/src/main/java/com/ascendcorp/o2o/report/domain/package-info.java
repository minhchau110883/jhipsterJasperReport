/**
 * JPA domain objects.
 */
package com.ascendcorp.o2o.report.domain;
