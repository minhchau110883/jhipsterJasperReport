package com.ascendcorp.o2o.report.job;

import com.ascendcorp.o2o.report.domain.Report;
import com.ascendcorp.o2o.report.domain.enumeration.ReportStatus;
import com.ascendcorp.o2o.report.repository.ReportRepository;
import com.ascendcorp.o2o.report.security.SecurityUtils;
import org.apache.commons.lang.StringUtils;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;

import java.time.ZonedDateTime;

import static com.ascendcorp.o2o.report.config.Constants.REPORT_ID_JOB_DATA_KEY;

@Component
public class SendReportEmailJob extends QuartzJobBean {

    private final Logger log = LoggerFactory.getLogger(SendReportEmailJob.class);

    @Autowired
    private ReportRepository reportRepository;

    @Override
    protected void executeInternal(JobExecutionContext jobExecutionContext) {
        log.info("Executing Job with key {}", jobExecutionContext.getJobDetail().getKey());

        JobDataMap jobDataMap = jobExecutionContext.getMergedJobDataMap();
        Long reportId = jobDataMap.getLong(REPORT_ID_JOB_DATA_KEY);
        Report report = reportRepository.findById(reportId).orElse(null);

        sendMail(report);
    }

    private void sendMail(Report report) {
        if (report != null) {
            log.info("Sending report ID {} to {} with public download URL {}", report.getId(), report.getEmail(), report.getPublicDownloadURL());
            report.setStatus(ReportStatus.SENT);
            report.setLastModifiedBy(SecurityUtils.getCurrentUserLogin().orElse(StringUtils.EMPTY));
            report.setLastModifiedDate(ZonedDateTime.now());
            reportRepository.save(report);
        } else {
            log.error("Cannot get a report ID {}", report.getId());
        }
    }
}
