package com.ascendcorp.o2o.report.service;

import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.net.URI;

public interface ReportStorageService {

    void upload(File file, String path);
    void upload(MultipartFile multipartFile, String path, String nameOfSourceFile) throws IOException;
    byte[] download(String path) throws IOException;
    URI generateDownloadURL(String path, Long expirationInSeconds);

}
