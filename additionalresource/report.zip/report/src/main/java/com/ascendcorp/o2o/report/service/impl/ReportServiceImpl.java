package com.ascendcorp.o2o.report.service.impl;

import com.ascendcorp.o2o.report.config.ApplicationProperties;
import com.ascendcorp.o2o.report.config.ReportProperties;
import com.ascendcorp.o2o.report.domain.Report;
import com.ascendcorp.o2o.report.domain.enumeration.ReportStatus;
import com.ascendcorp.o2o.report.repository.ReportRepository;
import com.ascendcorp.o2o.report.security.SecurityUtils;
import com.ascendcorp.o2o.report.service.ReportSchedulingService;
import com.ascendcorp.o2o.report.service.ReportService;
import com.ascendcorp.o2o.report.service.ReportStorageService;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.time.ZonedDateTime;

@Service
public class ReportServiceImpl implements ReportService {

    private final Logger log = LoggerFactory.getLogger(ReportServiceImpl.class);

    private final ReportRepository reportRepository;
    private final ReportStorageService reportStorageService;
    private final ReportSchedulingService reportSchedulingService;
    private final ApplicationProperties applicationProperties;

    @Autowired
    public ReportServiceImpl(ReportRepository reportRepository, ReportStorageService reportStorageService, ReportSchedulingService reportSchedulingService, ApplicationProperties applicationProperties) {
        this.reportRepository = reportRepository;
        this.reportStorageService = reportStorageService;
        this.reportSchedulingService = reportSchedulingService;
        this.applicationProperties = applicationProperties;
    }

    /**
     * Generate a mock report and save it to Report DB
     *
     * @param report A report to be saved
     * @return A saved report
     */
    @Override
    public Report generateMockReport(Report report) {
        log.info("Generating a mock report with data {}", report);
        String user = SecurityUtils.getCurrentUserLogin().orElse(StringUtils.EMPTY);
        ZonedDateTime currentDatetime = ZonedDateTime.now();
        report.setStatus(ReportStatus.CREATED);
        report.setCreatedBy(user);
        report.setCreatedDate(currentDatetime);
        report.setLastModifiedBy(user);
        report.setLastModifiedDate(currentDatetime);
        report = reportRepository.save(report);

        ReportProperties reportProperties = applicationProperties.getReportPropertiesByType(report.getType());
        Long expirationInSeconds = reportProperties.getExpirationInSeconds();
        String baseDownloadURL = reportProperties.getBaseDownloadURL();

        // We will not send the URL to download report directly from S3. We will let user download via our API instead.
        String publicDownloadURL = baseDownloadURL + report.getId() + "/download";
        String downloadURL = reportStorageService.generateDownloadURL(report.getFilePath(), expirationInSeconds).toString();
        report.setPublicDownloadURL(publicDownloadURL);
        report.setDownloadURL(downloadURL);
        reportRepository.save(report);

        reportSchedulingService.scheduleSendReportEmailJob(report);

        return report;
    }

    /**
     * Download a report using report ID to lookup a download link with expiration time in Report DB that was generated from S3 {@link S3ReportStorageServiceImpl}.
     *
     * There is another solution to download a report by using a normal download API from S3 {@link S3ReportStorageServiceImpl}.
     * In this case, we have to handle an expiration time by ourselves by adding a new expiration information in Report DB and using it to check expiration.
     *
     * @param id Report ID
     * @return Byte array of a report file
     * @throws Exception
     */
    @Override
    public byte[] downloadReport(Long id) throws Exception {
        Report report = reportRepository.findById(id).orElse(null);
        byte[] responseBytes = null;

        if (report != null) {
            log.info("Downloading report ID {} from download URL {}", report.getId(), report.getDownloadURL());
            responseBytes = new RestTemplate().exchange(new URI(report.getDownloadURL()), HttpMethod.GET, new HttpEntity<Void>(new HttpHeaders()), byte[].class).getBody();
            report.setStatus(ReportStatus.DOWNLOADED);
            report.setLastModifiedBy(SecurityUtils.getCurrentUserLogin().orElse(StringUtils.EMPTY));
            report.setLastModifiedDate(ZonedDateTime.now());
            reportRepository.save(report);
        } else {
            log.error("Cannot get a report ID {}", id);
        }

        return responseBytes;
    }
}
