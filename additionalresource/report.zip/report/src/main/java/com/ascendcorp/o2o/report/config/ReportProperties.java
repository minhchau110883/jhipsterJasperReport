package com.ascendcorp.o2o.report.config;

public class ReportProperties {

    private String baseDownloadURL;
    private Long expirationInSeconds;
    private ScheduleProperties emailScheduling;

    public String getBaseDownloadURL() {
        return baseDownloadURL;
    }

    public void setBaseDownloadURL(String baseDownloadURL) {
        this.baseDownloadURL = baseDownloadURL;
    }

    public Long getExpirationInSeconds() {
        return expirationInSeconds;
    }

    public void setExpirationInSeconds(Long expirationInSeconds) {
        this.expirationInSeconds = expirationInSeconds;
    }

    public ScheduleProperties getEmailScheduling() {
        return emailScheduling;
    }

    public void setEmailScheduling(ScheduleProperties emailScheduling) {
        this.emailScheduling = emailScheduling;
    }
}
