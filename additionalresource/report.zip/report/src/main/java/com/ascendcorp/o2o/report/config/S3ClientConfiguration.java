package com.ascendcorp.o2o.report.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;

@Configuration
public class S3ClientConfiguration {
    private final ApplicationProperties applicationProperties;

    @Autowired
    public S3ClientConfiguration(ApplicationProperties applicationProperties) {
        this.applicationProperties = applicationProperties;
    }

    @Bean
    @Qualifier("s3Client")
    public S3Client config() {
        AwsBasicCredentials awsCreds = AwsBasicCredentials.create(
            applicationProperties.getAws().getAccessKey(),
            applicationProperties.getAws().getSecretKey());

        Region region = Region.of(applicationProperties.getAws().getRegion());

        return S3Client.builder()
            .credentialsProvider(StaticCredentialsProvider.create(awsCreds))
            .region(region)
            .build();
    }
}
