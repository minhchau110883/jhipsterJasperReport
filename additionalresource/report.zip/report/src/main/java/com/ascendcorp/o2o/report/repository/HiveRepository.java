package com.ascendcorp.o2o.report.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ascendcorp.o2o.report.domain.MakroSettlement;
import com.ascendcorp.o2o.report.domain.mapper.MakroSettlementRowMapper;

@Repository
public class HiveRepository {

    private final JdbcTemplate jdbcTemplate;

    public HiveRepository(@Qualifier("hiveJdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<MakroSettlement> getMakroSettlementRecords(int limit) {
        return (List<MakroSettlement>) jdbcTemplate.query("select * from tmn_retail_merchant.makro_settlement limit ?",
                new Object[] { limit }, new MakroSettlementRowMapper());

    }
}
