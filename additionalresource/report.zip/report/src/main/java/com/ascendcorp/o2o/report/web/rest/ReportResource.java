package com.ascendcorp.o2o.report.web.rest;

import com.ascendcorp.o2o.report.domain.MakroSettlement;
import com.ascendcorp.o2o.report.domain.Report;
import com.ascendcorp.o2o.report.service.HiveReportService;
import com.ascendcorp.o2o.report.service.ReportService;
import com.codahale.metrics.annotation.Timed;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api")
public class ReportResource {

    private final Logger log = LoggerFactory.getLogger(ReportResource.class);

    private final HiveReportService hiveReportService;
    private final ReportService reportService;

    public ReportResource(HiveReportService hiveReportService, ReportService reportService) {
        this.hiveReportService = hiveReportService;
        this.reportService = reportService;
    }

    /**
     * GET /report/makro-settlement: get Makro Settlement records from Hive
     *
     * @return the ResponseEntity with status 200 (OK) and the list of Makro Settlement records in body
     * or with status 401 (Unauthorized)
     * or with status 403 (Forbidden)
     */
    @GetMapping("/report/makro-settlement")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "queryLimit", paramType = "query", dataType = "integer")
    })
    @Timed
    public ResponseEntity<List<MakroSettlement>> makroSettlementReport(@RequestParam("queryLimit") int queryLimit) {
        log.info("REST request get Makro Settlement records");
        List<MakroSettlement> result = hiveReportService.getMakroSettlementRecords(queryLimit);
        return ResponseEntity.ok().body(result);
    }

    /**
     * GET /report/{id}/download: Download a report
     *
     * @param id An ID of target report
     * @return Report file
     */
    @GetMapping("/report/{id}/download")
    public ResponseEntity<byte[]> downloadReport(@PathVariable Long id) throws Exception {
        log.info("REST request to download report");

        byte[] byteReport = reportService.downloadReport(id);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition",  "attachment; filename=report.xlsx");
        return ResponseEntity.ok()
            .headers(headers)
            .contentLength(byteReport.length)
            .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
            .body(byteReport);
    }

    /**
     * POST /report/generate-mock-report: Generate a mock report
     *
     * @return the ResponseEntity with status 200 (OK) and the Report in body
     * or with status 401 (Unauthorized)
     * or with status 403 (Forbidden)
     */
    @PostMapping("/report/generate-mock-report")
    public ResponseEntity<Report> generateMockReport(@RequestBody Report report) {
        Report result = reportService.generateMockReport(report);
        return ResponseEntity.ok().body(result);
    }
}
