package com.ascendcorp.o2o.report.service.impl;

import com.ascendcorp.o2o.report.config.ApplicationProperties;
import com.ascendcorp.o2o.report.service.ReportStorageService;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.auth.signer.AwsS3V4Signer;
import software.amazon.awssdk.auth.signer.params.Aws4PresignerParams;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.http.SdkHttpFullRequest;
import software.amazon.awssdk.http.SdkHttpMethod;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;
import java.time.Instant;

@Service
public class S3ReportStorageServiceImpl implements ReportStorageService {

    private final Logger log = LoggerFactory.getLogger(S3ReportStorageServiceImpl.class);

    private final S3Client s3Client;

    private final ApplicationProperties applicationProperties;

    @Autowired
    public S3ReportStorageServiceImpl(ApplicationProperties applicationProperties, S3Client s3Client) {
        this.applicationProperties = applicationProperties;
        this.s3Client = s3Client;
    }

    public void upload(File file, String path) {
        log.info("Upload file {} to path {}", file, path);
        PutObjectRequest request = PutObjectRequest.builder()
            .bucket(applicationProperties.getAws().getBucketName())
            .key(path)
            .build();

        RequestBody requestBody = RequestBody.fromFile(file);

        s3Client.putObject(request, requestBody);
    }

    public void upload(MultipartFile multipartFile, String path, String nameOfSourceFile) throws IOException {
        log.info("Upload multipartFile {} to path {} with total {} files", multipartFile, path, nameOfSourceFile);
        PutObjectRequest request = PutObjectRequest.builder()
            .bucket(applicationProperties.getAws().getBucketName())
            .key(path + nameOfSourceFile)
            .build();

        File file = convertMultiPartToFile(multipartFile);
        RequestBody requestBody = RequestBody.fromFile(file);

        s3Client.putObject(request, requestBody);
    }

    public byte[] download(String path) throws IOException {
        log.info("Download file from path {}", path);
        GetObjectRequest request = GetObjectRequest.builder()
            .bucket(applicationProperties.getAws().getBucketName())
            .key(path)
            .build();

        return IOUtils.toByteArray(s3Client.getObject(request));
    }

    public URI generateDownloadURL(String path, Long expirationInSeconds) {
        log.info("Generate download URL for {}", path);
        Region region = Region.of(applicationProperties.getAws().getRegion());
        AwsBasicCredentials awsCredentials = AwsBasicCredentials.create(
            applicationProperties.getAws().getAccessKey(),
            applicationProperties.getAws().getSecretKey());

        // AWS SDK v2 does not provide generate pre-signed URL feature. So, this is a workaround from https://github.com/aws/aws-sdk-java-v2/issues/868
        Aws4PresignerParams params = Aws4PresignerParams.builder()
            .expirationTime(Instant.ofEpochSecond(expirationInSeconds))
            .awsCredentials(StaticCredentialsProvider.create(awsCredentials).resolveCredentials())
            .signingName("s3")
            .signingRegion(region)
            .build();

        SdkHttpFullRequest request = SdkHttpFullRequest.builder()
            .encodedPath("/" + applicationProperties.getAws().getBucketName() + "/" + path)
            .host("s3-" + region + ".amazonaws.com")
            .method(SdkHttpMethod.GET)
            .protocol("https")
            .build();

        URI downloadURI = AwsS3V4Signer.create().presign(request, params).getUri();
        log.info("Download URL for {} is {}", path, downloadURI);

        return downloadURI;
    }

    private File convertMultiPartToFile(MultipartFile multipartFile) throws IOException {
        File file = new File(multipartFile.getOriginalFilename());
        FileOutputStream fos = new FileOutputStream(file);
        fos.write(multipartFile.getBytes());
        fos.close();
        return file;
    }
}
