package com.ascendcorp.o2o.report.service;

import java.util.List;

import com.ascendcorp.o2o.report.domain.MakroSettlement;

public interface HiveReportService {

    List<MakroSettlement> getMakroSettlementRecords(int queryLimit);

}
